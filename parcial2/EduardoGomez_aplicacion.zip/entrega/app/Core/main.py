from app.Core.Controller import App

app = App.App('FastShipping', 'Miami Gardens FL 33169')
